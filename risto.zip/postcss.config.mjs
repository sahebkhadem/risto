/** @type {import('postcss').ProcessOptions} */
export default {
	plugins: {
		"@tailwindcss/postcss": {}
	}
};
