import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { z } from "zod";
import { sendVerificationEmail } from "@/lib/mail";
import { regenerateVerificationToken } from "@/lib/verification";
import { checkAndUpdateRateLimit } from "@/lib/rateLimiting";

const regenerateTokenSchema = z.object({
	email: z
		.string()
		.email("Invalid email address.")
		.min(1, "Invalid email address.")
});

export async function POST(req: NextRequest) {
	try {
		const body = await req.json();
		const { email } = regenerateTokenSchema.parse(body);

		// Find user by email
		const user = await prisma.user.findUnique({ where: { email } });

		if (!user) {
			return NextResponse.json(
				{
					error:
						"No user found with this email address. Please check and try again."
				},
				{ status: 404 }
			);
		}

		// Rate limiting check
		const allowed = await checkAndUpdateRateLimit(user.id);
		if (!allowed) {
			return NextResponse.json(
				{ error: "Too many requests. Please try again later." },
				{ status: 429 }
			);
		}

		// Regenerate token and send email
		const token = await regenerateVerificationToken(user.id);
		await sendVerificationEmail(user.email, token);

		console.log("Successfully generated token.");
		return NextResponse.json(
			{ message: "Verification email sent. Please check your inbox." },
			{ status: 201 }
		);
	} catch (error) {
		if (error instanceof z.ZodError) {
			return NextResponse.json(
				{
					errors: error.errors.map((e) => ({
						field: e.path[0],
						error: e.message
					}))
				},
				{ status: 400 }
			);
		}

		console.error(error);
		return NextResponse.json(
			{ error: "Internal server error" },
			{ status: 500 }
		);
	}
}
