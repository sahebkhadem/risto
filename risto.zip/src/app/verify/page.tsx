"use client";

import FullHeightContainer from "@/components/layout/FullHeightContainer";
import InvalidToken from "@/components/verification-status/InvalidToken";
import Verified from "@/components/verification-status/Verified";
import Verifying from "@/components/verification-status/Verifying";
import { useAuthStore } from "@/store/useAuthStore";
import { useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";
import { toast } from "sonner";

type TokenStatus = "verifying" | "invalid" | "verified";

export default function Verify() {
	const [tokenStatus, setTokenStatus] = useState<TokenStatus>("verifying");
	const params = useSearchParams();

	useEffect(() => {
		const token = params.get("token");
		if (!token) {
			setTokenStatus("invalid");
			return;
		}

		const verifyEmail = async () => {
			try {
				const res = await fetch(
					`/api/auth/verify?token=${params.get("token")}`
				);

				const data = await res.json();

				if (!res.ok) {
					setTokenStatus("invalid");
					throw new Error(data.error || "Sorry, something went wrong.");
				}

				useAuthStore.getState().setUser(data.user);
				setTokenStatus("verified");
			} catch (error: any) {
				toast.error(error);
			}
		};

		verifyEmail();
	}, []);

	return (
		<FullHeightContainer>
			{tokenStatus === "verifying" && <Verifying />}
			{tokenStatus === "invalid" && <InvalidToken />}
			{tokenStatus === "verified" && <Verified />}
		</FullHeightContainer>
	);
}
