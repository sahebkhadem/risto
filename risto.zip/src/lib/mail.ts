import { Resend } from "resend";
import { render, pretty } from "@react-email/render";
import VerificationEmail from "@/emails/VerificationEmail";
import { createElement } from "react";

if (!process.env.RESEND_API_KEY) {
	throw new Error("RESEND_API_KEY is not set in environment variables.");
}

const resend = new Resend(process.env.RESEND_API_KEY);

export async function sendVerificationEmail(to: string, token: string) {
	const confirmUrl = `${process.env.NEXT_PUBLIC_APP_URL}/verify?token=${token}`;

	const html = await pretty(
		await render(
			createElement(VerificationEmail, { url: confirmUrl, email: to })
		)
	);
	const text = `Verify your email for Risto: ${confirmUrl}`;

	try {
		const { data, error } = await resend.emails.send({
			from: "Risto <onboarding@resend.dev>", // change to your domain later
			to,
			subject: "Action required to verify your account",
			html,
			text
		});
	} catch (error) {
		console.error("Email send failed:", error);
	}
}
