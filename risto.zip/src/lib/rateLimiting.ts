import prisma from "@/lib/prisma";

export async function checkAndUpdateRateLimit(
	userId: string,
	maxRequests = 3,
	windowMs = 1000 * 60 * 60
) {
	const now = new Date();
	const windowEnd = new Date(now.getTime() + windowMs);

	let rateLimit = await prisma.rateLimit.findUnique({
		where: { userId }
	});

	if (rateLimit && rateLimit.windowEnd > now) {
		if (rateLimit.count >= maxRequests) {
			return false; // Rate limit exceeded
		}
		await prisma.rateLimit.update({
			where: { userId },
			data: { count: { increment: 1 } }
		});
	} else {
		await prisma.rateLimit.upsert({
			where: { userId },
			update: { count: 1, windowEnd },
			create: { userId, count: 1, windowEnd }
		});
	}
	return true; // Allowed
}
